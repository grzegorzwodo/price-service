package com.altapay.backend.services;


import com.altapay.backend.exceptions.InsufficientInventoryException;
import com.altapay.backend.model.Product;
import com.altapay.backend.model.Inventory;
import com.altapay.backend.repositories.InventoryRepository;

public class InventoryService
{
	private InventoryRepository repository;

	public InventoryService(InventoryRepository repository) {
		this.repository = repository;
	}

	public boolean checkInventory(Product product, int quantity) {
		Inventory inventory = repository.load(product.getId());
		return inventory.quantityIsAvailable(quantity);
	}

	public void releaseProductsInInventory(Product product, int quantity) {
		Inventory inventory = repository.load(product.getId());
		inventory.releaseProducts(quantity);
	}

	public void lockProductsInInventory(Product product, int quantity) throws InsufficientInventoryException {
		Inventory inventory = repository.load(product.getId());
		inventory.lockProducts(quantity);
	}

	public boolean takeFromInventory(Product product, int quantity) {
		Inventory inventory = repository.load(product.getId());
		inventory.takeItems(quantity);
		try {
			repository.save(inventory);
		} catch (Exception e) {
			System.out.println("Cannot take items from inventory");
			e.printStackTrace();
			return false;
		}
		return true;
	}
}