package com.altapay.backend.services;

public class ReleaseResponse {
	private boolean successful;

	public ReleaseResponse(boolean successful) {
		this.successful = successful;
	}

	public boolean wasSuccessful() {
		return successful;
	}
}
