package com.altapay.backend.exceptions;

public class MerchantApiServiceException extends Exception {

    public MerchantApiServiceException(String message) {
        super(message);
    }
}
