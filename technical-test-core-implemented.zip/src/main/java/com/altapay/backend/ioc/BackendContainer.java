package com.altapay.backend.ioc;

import com.altapay.backend.controllers.BackendController;
import com.altapay.backend.model.IModelFactory;
import com.altapay.backend.model.Inventory;
import com.altapay.backend.model.OrderLine;
import com.altapay.backend.model.Product;
import com.altapay.backend.model.ShopOrder;
import com.altapay.backend.repositories.InventoryRepository;
import com.altapay.backend.repositories.ShopOrderRepository;
import com.altapay.backend.services.InventoryService;
import com.altapay.backend.services.MerchantApiService;
import com.altapay.util.HttpUtil;
import com.altapay.util.XpathUtil;

public class BackendContainer implements IModelFactory {

	private static ShopOrderRepository shopOrderRepositoryInstance;

	public BackendController getBackendController()
	{
		return new BackendController(getShopOrderRepository());
	}

	public ShopOrderRepository getShopOrderRepository()
	{
		if (shopOrderRepositoryInstance == null) {
			shopOrderRepositoryInstance = new ShopOrderRepository(this);
		}
		return shopOrderRepositoryInstance;
	}

	@Override
	public ShopOrder getShopOrder()
	{
		return new ShopOrder(getInventoryService(), getMerchantService());
	}

	private InventoryService getInventoryService() {
		return new InventoryService(new InventoryRepository());
	}

	private MerchantApiService getMerchantService() {
		return new MerchantApiService(new HttpUtil(), new XpathUtil());
	}

	@Override
	public Inventory getInventory()
	{
		return new Inventory();
	}

	@Override
	public OrderLine getOrderLine()
	{
		return new OrderLine();
	}

	@Override
	public Product getProduct()
	{
		return new Product();
	}
}
