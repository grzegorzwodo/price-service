package com.altapay.backend.model;

import com.altapay.backend.exceptions.InsufficientInventoryException;

public class Inventory
{
	private Product product;
	private int inventory;
	private int lockedInventory;
	
	public Product getProduct() 
	{
		return product;
	}
	
	public void setProduct(Product product) 
	{
		this.product = product;
	}
	
	public int getInventory() 
	{
		return inventory;
	}
	
	public void setInventory(int inventory) 
	{
		this.inventory = inventory;
	}

	public boolean quantityIsAvailable(int quantity) {
		return (inventory - lockedInventory) >= quantity;
	}

	public void takeItems(int quantity) {
		this.lockedInventory = this.lockedInventory - quantity;
		this.inventory = this.inventory - quantity;
	}

	public void lockProducts(int quantity) throws InsufficientInventoryException {
		if(this.lockedInventory + quantity > inventory) {
			throw new InsufficientInventoryException("Cannot lock products in inventory");
		}
		this.lockedInventory = this.lockedInventory + quantity;
	}

	public void releaseProducts(int quantity) {
		this.lockedInventory = this.lockedInventory - quantity;
	}
}
