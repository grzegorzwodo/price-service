package com.altapay.backend.model;

import com.altapay.backend.exceptions.InsufficientInventoryException;
import com.altapay.backend.services.CaptureResponse;
import com.altapay.backend.services.InventoryService;
import com.altapay.backend.services.MerchantApiService;
import com.altapay.backend.exceptions.MerchantApiServiceException;
import com.altapay.backend.services.ReleaseResponse;

import java.util.ArrayList;
import java.util.List;


public class ShopOrder
{
	String id;
	String paymentId;
	List<OrderLine> orderLines;
	private InventoryService inventoryService;
	private MerchantApiService merchantApiService;

	public void setId(String id) {
		this.id = id;
	}

	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	public void setOrderLines(List<OrderLine> orderLines) {
		this.orderLines = orderLines;
	}

	public void addOrderLines(OrderLine orderLine) {
		if(orderLines == null) {
			orderLines = new ArrayList<>();
		}
		orderLines.add(orderLine);
	}
	public ShopOrder(InventoryService inventoryService, MerchantApiService merchantApiService) {
		this.inventoryService = inventoryService;
		this.merchantApiService = merchantApiService;
	}

	public void capture() throws InsufficientInventoryException, MerchantApiServiceException
	{
		for (OrderLine line : orderLines) {
			boolean isAvailable = inventoryService.checkInventory(line.getProduct(), line.getQuantity());
			if (!isAvailable) {
				throw new InsufficientInventoryException("Insufficient inventory for product: " + line.getProduct().getName());
			}
		}

		CaptureResponse response = merchantApiService.capturePayment(this);
		if (!response.wasSuccessful()) {
			for (OrderLine line : orderLines) {
				inventoryService.releaseProductsInInventory(line.getProduct(), line.getQuantity());
			}
			throw new MerchantApiServiceException("Failed to capture payment for order: " + id);
		}

		for (OrderLine line : orderLines) {
			inventoryService.takeFromInventory(line.getProduct(), line.getQuantity());
		}
	}

	public void release() throws MerchantApiServiceException
	{
		ReleaseResponse response = merchantApiService.releasePayment(this);
		if (!response.wasSuccessful()) {
			throw new MerchantApiServiceException("Failed to release payment for order: " + id);
		}
	}
}