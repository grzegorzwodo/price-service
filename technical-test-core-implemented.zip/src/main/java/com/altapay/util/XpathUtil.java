package com.altapay.util;


public class XpathUtil {
	public String xpath(String source, String xpathString)
		throws Exception {
		// We don't need to implement this, write the rest of the code as if this just works
		return null;
	}
}