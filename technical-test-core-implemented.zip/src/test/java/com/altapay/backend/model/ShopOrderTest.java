package com.altapay.backend.model;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import com.altapay.backend.exceptions.InsufficientInventoryException;
import com.altapay.backend.exceptions.MerchantApiServiceException;
import com.altapay.backend.services.CaptureResponse;
import com.altapay.backend.services.InventoryService;
import com.altapay.backend.services.MerchantApiService;
import com.altapay.backend.services.ReleaseResponse;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class ShopOrderTest {

	private static final String ID = "orderid";
	private static final String PAYMENT_ID = "paymentid";
	private static final String PRODUCT_ID = "prod_id";
	private static final String PRODUCT_NAME = "test_name";
	private ShopOrder order;

	@Mock
	private MerchantApiService merchantApiService;

	@Mock
	private InventoryService inventoryService;

	@Before
	public void setUp() throws Exception
	{
		MockitoAnnotations.initMocks(this);
		order = new ShopOrder(inventoryService, merchantApiService);
		order.setId(ID);
		order.setPaymentId(PAYMENT_ID);
		order.addOrderLines(new OrderLine(new Product(PRODUCT_ID, PRODUCT_NAME), 1));
	}

	@Test
	public void executeCapture_inventoryIsChecked() throws MerchantApiServiceException, InsufficientInventoryException {
		when(inventoryService.checkInventory(any(), anyInt())).thenReturn(true);
		when(merchantApiService.capturePayment(any())).thenReturn(new CaptureResponse(true));

		order.capture();

		verify(inventoryService, atLeastOnce()).checkInventory(any(), anyInt());
	}

	@Test
	public void executeCapture_paymentIsCapturedThroughApiService() throws MerchantApiServiceException, InsufficientInventoryException {
		when(inventoryService.checkInventory(any(), anyInt())).thenReturn(true);
		when(merchantApiService.capturePayment(any())).thenReturn(new CaptureResponse(true));

		order.capture();

		verify(merchantApiService).capturePayment(order);
	}

	@Test
	public void executeRelease_paymentIsReleasedThroughApiService() throws MerchantApiServiceException {
		when(inventoryService.checkInventory(any(), anyInt())).thenReturn(true);
		when(merchantApiService.releasePayment(any())).thenReturn(new ReleaseResponse(true));

		order.release();
		verify(merchantApiService).releasePayment(order);
	}

	@Test
	public void capture_throwsException_whenInventoryIsInsufficient() throws MerchantApiServiceException{
		when(inventoryService.checkInventory(any(), anyInt())).thenReturn(false);
		try {
			order.capture();
			fail("Expected InsufficientInventoryException to be thrown");
		} catch (InsufficientInventoryException e) {
			assertNotNull(e);
		}
    }

	@Test
	public void capture_throwsException_whenPaymentFails() throws InsufficientInventoryException, MerchantApiServiceException {
		when(inventoryService.checkInventory(any(), anyInt())).thenReturn(true);
		when(merchantApiService.capturePayment(order)).thenReturn(new CaptureResponse(false));
		try {
			order.capture();
			fail("Expected MerchantApiServiceException to be thrown");
			verify(inventoryService, times(1)).releaseProductsInInventory(any(), any());
		} catch (MerchantApiServiceException e) {
			assertNotNull(e);
		}
	}

	@Test
	public void capture_reducesInventory_whenSuccessful() throws MerchantApiServiceException, InsufficientInventoryException {
		when(inventoryService.checkInventory(any(), anyInt())).thenReturn(true);
		when(merchantApiService.capturePayment(order)).thenReturn(new CaptureResponse(true));

		order.capture();
		verify(inventoryService, times(1)).takeFromInventory(any(), anyInt());
	}

	@Test
	public void release_throwsException_whenPaymentReleaseFails() throws MerchantApiServiceException {
		when(merchantApiService.releasePayment(order)).thenReturn(new ReleaseResponse(false));
		try {
			order.release();
			fail("Expected MerchantApiServiceException to be thrown");
			verify(inventoryService, times(1)).releaseProductsInInventory(any(), any());
		} catch (MerchantApiServiceException e) {
			assertNotNull(e);
		}
	}
}